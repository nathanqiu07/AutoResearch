"""Archive only approved committed code/control paths; never read working-tree secrets."""
import argparse
import hashlib
import io
import json
import os
from pathlib import Path
import subprocess
import tarfile

p = argparse.ArgumentParser(description=__doc__)
p.add_argument('--repo', type=Path, required=True)
p.add_argument('--commit', required=True)
p.add_argument('--out', type=Path, required=True)
p.add_argument('--compare-snapshot', type=Path, required=True)
a = p.parse_args()
prefix = 'docs/overnight/gio-profile-20261115/control/'
paths = ['autoresearch', 'tests'] + [prefix + name for name in
    ('run_batch.py', 'test_run_batch.py', 'pilot-selection-v1.json', 'PILOT_PROTOCOL.md', 'RUN_POLICY.json')]
argv = ['git', '--no-optional-locks', '-C', str(a.repo.resolve()), 'archive', a.commit, *paths]
env = dict(os.environ, GIT_NO_REPLACE_OBJECTS='1', GIT_NO_LAZY_FETCH='1', GIT_TERMINAL_PROMPT='0')
result = subprocess.run(argv, capture_output=True, env=env)
if result.returncode:
    raise SystemExit(result.stderr.decode())
a.out.mkdir(parents=True, exist_ok=False)
files = {}
with tarfile.open(fileobj=io.BytesIO(result.stdout), mode='r:') as archive:
    for member in archive.getmembers():
        relative = Path(member.name)
        if relative.is_absolute() or '..' in relative.parts:
            raise ValueError('Unsafe archive path')
        if member.isdir():
            continue
        if not member.isfile():
            raise ValueError('Only ordinary source files are allowed')
        allowed = member.name.startswith(('autoresearch/', 'tests/')) or member.name in paths
        if not allowed or relative.name == 'project.env':
            raise ValueError('Unapproved archive member')
        data = archive.extractfile(member).read()
        dest = a.out / relative
        dest.parent.mkdir(parents=True, exist_ok=True)
        dest.write_bytes(data)
        files[member.name] = hashlib.sha256(data).hexdigest()
previous = json.loads((a.compare_snapshot / 'AUDIT_SOURCE.json').read_text())
common = []
for name, digest in files.items():
    if name.startswith('autoresearch/') and name in previous['files']:
        common.append({'path': name, 'previous_sha256': previous['files'][name],
                       'current_sha256': digest, 'matches': previous['files'][name] == digest})
metadata = {'source_commit': a.commit, 'argv': argv, 'exit_code': result.returncode,
            'archive_sha256': hashlib.sha256(result.stdout).hexdigest(), 'files': files,
            'comparison_source_commit': previous['source_commit'], 'runtime_comparison': common,
            'excluded': ['project.env', 'private evaluator roots', 'labels', 'nonselected control/hand-off files']}
(a.out / 'AUDIT_SOURCE.json').write_text(json.dumps(metadata, sort_keys=True, indent=2) + '\n')
(a.out.parent / 'selective-source.tar').write_bytes(result.stdout)
(a.out.parent / 'archive-command.json').write_text(json.dumps({'argv': argv, 'exit_code': 0,
    'stdout_sha256': metadata['archive_sha256'], 'stdout_bytes': len(result.stdout),
    'stderr': result.stderr.decode()}, indent=2) + '\n')
print(json.dumps({'files': len(files), 'common_runtime_files': len(common),
                  'runtime_changes': [row['path'] for row in common if not row['matches']],
                  'archive_sha256': metadata['archive_sha256']}, indent=2))
