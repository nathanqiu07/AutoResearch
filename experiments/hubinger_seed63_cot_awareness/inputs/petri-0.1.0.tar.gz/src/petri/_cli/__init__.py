"""Petri CLI module."""


